package com.springbootcontentnegotiation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContentnegdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContentnegdemoApplication.class, args);
	}

}
