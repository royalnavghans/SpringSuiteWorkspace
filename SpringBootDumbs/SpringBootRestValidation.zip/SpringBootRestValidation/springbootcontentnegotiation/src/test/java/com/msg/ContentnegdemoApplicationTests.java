package com.msg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContentnegdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
