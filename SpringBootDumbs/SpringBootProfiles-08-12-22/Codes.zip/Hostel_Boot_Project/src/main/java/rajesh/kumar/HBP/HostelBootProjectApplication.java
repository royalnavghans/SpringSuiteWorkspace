package rajesh.kumar.HBP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostelBootProjectApplication.class, args);
	}

}
