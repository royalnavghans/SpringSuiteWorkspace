package binod.suman.Hostel_Boot_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostelBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
