package com.restemp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbtApplication.class, args);
	}

}
