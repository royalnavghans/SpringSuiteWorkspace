package com.cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCacheExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
