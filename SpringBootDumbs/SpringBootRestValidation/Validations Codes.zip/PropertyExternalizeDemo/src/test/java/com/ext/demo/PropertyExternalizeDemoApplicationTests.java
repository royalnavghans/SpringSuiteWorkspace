package com.ext.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyExternalizeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
