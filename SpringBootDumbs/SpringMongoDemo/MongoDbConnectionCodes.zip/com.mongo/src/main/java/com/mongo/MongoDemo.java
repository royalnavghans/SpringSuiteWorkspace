package com.mongo;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

public class MongoDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   MongoClient mongo =new MongoClient("localhost",27017);
   System.out.println("connection sucess");
   
   DB db=mongo.getDB("Royalnavghan");
   System.out.println("DB created");
   
   DBCollection collect=db.createCollection("RoyalCollection", null);
   
   System.out.println("collecction created");
   
   //insert data into db
   
//   BasicDBObject dbobj=new BasicDBObject("name","royal")
//		   .append("age",26 ).append("city", "Coimbatore");
   BasicDBObject dbobj=new BasicDBObject("name","navghan")
		   .append("age",26 ).append("city", "Coimbatore");
   BasicDBObject dbobj1=new BasicDBObject("name","royal")
		   .append("age",26 ).append("city", "Coimbatore");
   
   //collect.insert(dbobj1);
   //collect.remove(dbobj1);
   collect.update(dbobj, dbobj1);
   
   
   //fetching data from collection
   
   DBCursor fetch=collect.find();
   
   //System.out.println(fetch);
   
   while(fetch.hasNext()) {
	   System.out.println(fetch.next());
   }
   
	}

}
