package com.mongo;

import java.util.Iterator;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MongoClient mongo =new MongoClient("localhost",27017);
		
		MongoDatabase db=mongo.getDatabase("RoyalNew");
		
		db.getCollection("navghanCollection");
		
		//preparing Document
		
		Document doc=new Document();
		doc.append("name", "abc").append("age",23 ).append("city", "hyd");
		
		//inserting this data into collection
		
		db.getCollection("navghanCollection").insertOne(doc);
		
		System.out.println("inserted sucess");
		
		MongoCollection<Document>collObj=db.getCollection("navghanCollection");
		FindIterable<Document>itr=collObj.find();
		
		Iterator it =itr.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
